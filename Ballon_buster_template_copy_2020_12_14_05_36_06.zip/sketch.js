var bow,arrow,arrow1,bow1;

function preload(){
 //load your images here 
 arrow1=
   loadAnimation("arrow0.png");
  bow1=
    loadAnimation("bow0.png");
  balloons=
    loadAnimation("red_balloon0.png");
  balloon2=
    loadAnimation("pink_balloon0.png");
   balloons3=
    loadAnimation("green_balloon0.png");
   balloon14=
    loadAnimation("blue_balloon0.png");
  background1=
    loadAnimation("background0.png");
  background1.scale=0.3;
}

function setup() {
  createCanvas(600, 600);
  
  //add code here
 var     background2=createSprite(200,200,600,600);
background2.addAnimation("background0",background1);
 
 var arrow=createSprite(340,200);
arrow.addAnimation("arrow0",arrow1);
 var bow=createSprite(380,200);
  bow.addAnimation("bow0",bow1);
 arrow.scale=0.3;
 var balloon=createSprite(130,200);
  balloon.scale=0.1;
  balloon.addAnimation("red_balloon0",balloons);
var balloon1=createSprite(250,200,20);
  balloon1.addAnimation("pink_balloon0",balloon2);
  balloon1.scale=1.3;
  var balloon3=createSprite(200,150,20);
  balloon3.addAnimation("pink_balloon0",balloon2);
  balloon3.scale=1.3;
  
  var balloon4=createSprite(200,250,20);
  balloon4.addAnimation("pink_balloon0",balloon2);
  balloon4.scale=1.3;
  var balloon5=createSprite(200,350,20);
  balloon5.addAnimation("pink_balloon0",balloon2);
  balloon5.scale=1.3;
  var balloon6=createSprite(200,50,20);
  balloon6.addAnimation("pink_balloon0",balloon2);
  balloon6.scale=1.3;
  var balloon7=createSprite(170,100,20);
  balloon7.addAnimation("green_balloon0",balloons3);
  balloon7.scale=0.1;
  var balloon8=createSprite(170,300,20);
  balloon8.addAnimation("green_balloon0",balloons3);
  balloon8.scale=0.1;
  var balloon9=createSprite(170,200,20);
  balloon9.addAnimation("green_balloon0",balloons3);
  balloon9.scale=0.1;
  

  var balloon12=createSprite(90,200,20);
  balloon12.addAnimation("blue_balloon0",balloon14);
  balloon12.scale=0.1;
   
 
  
}

function draw() {
   background("white");
   if (background1.x<200){
      background1.x = 200;
     background1.y=200;
  }
  
      
  drawSprites();
   
 
           
}
   
  
  
  